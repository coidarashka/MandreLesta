"""Initialize the index package"""
# flake8: noqa
from .base import *
from .typ import *
