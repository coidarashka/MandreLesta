from __future__ import annotations

from typing import Union

from .input_poll_option import InputPollOption

InputPollOptionUnion = Union[InputPollOption, str]
