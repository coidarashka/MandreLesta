from __future__ import annotations

from typing import Union

ChatIdUnion = Union[int, str]
