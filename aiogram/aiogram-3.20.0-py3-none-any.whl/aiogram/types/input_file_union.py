from __future__ import annotations

from typing import Union

from .input_file import InputFile

InputFileUnion = Union[str, InputFile]
